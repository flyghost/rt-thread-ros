/*
 * Copyright (c) 2025, sakumisu
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * MTP操作命令处理实现
 */

#include "mtp_operation.h"
#include "usb_config.h"
#include "usbd_mtp.h"
#include "usb_mtp.h"
#include "usbd_mtp_support.h"
#include "mtp_storage.h"
#include "mtp_filesystem.h"
#include <string.h>

#define MTP_STORAGE_ID 0x00010001

#define MTP_LOGD(fmt, ...) rt_kprintf("MTP : " fmt "\r\n", ##__VA_ARGS__)

extern struct mtp_object object_pool[CONFIG_USBDEV_MTP_MAX_OBJECTS];
extern uint32_t object_count;

extern int usbd_mtp_start_write(uint8_t *buf, uint32_t len);

// 辅助函数：打包MTP字符串（返回新offset）
static uint32_t mtp_pack_string(uint8_t *buf, uint32_t offset, const char *str) {
    if (!str || !str[0]) {
        buf[offset++] = 0; // 空字符串，长度为0
        return offset;
    }
    uint8_t len = 0;
    const char *p = str;
    while (*p) { len++; p++; }
    buf[offset++] = len;
    for (uint8_t i = 0; i < len; i++) {
        buf[offset++] = str[i];
        buf[offset++] = 0x00; // UTF-16LE低字节
    }
    // 不需要结尾补0
    return offset;
}

// 辅助函数：打包MTP数组（返回新offset）
static uint32_t mtp_pack_uint16_array(uint8_t *buf, uint32_t offset, const uint16_t *arr, uint16_t count) {
    *(uint16_t*)(buf + offset) = count;
    offset += 2;
    for (uint16_t i = 0; i < count; i++) {
        *(uint16_t*)(buf + offset) = arr[i];
        offset += 2;
    }
    return offset;
}

static int mtp_get_device_info(struct mtp_header *hdr)
{
    uint8_t *tx_buf = g_usbd_mtp.tx_buffer;
    uint32_t offset = sizeof(struct mtp_header) + 4; // 预留空间：响应头 + 会话ID

    // 1. 固定长度字段
    *(uint16_t*)(tx_buf + offset) = MTP_VERSION;
    offset += 2;
    *(uint32_t*)(tx_buf + offset) = 6; // VendorExtensionID
    offset += 4;
    *(uint16_t*)(tx_buf + offset) = 100; // VendorExtensionVersion
    offset += 2;

    // 2. VendorExtensionDesc
    offset = mtp_pack_string(tx_buf, offset, mtp_extension_string);

    // 3. FunctionalMode
    *(uint16_t*)(tx_buf + offset) = 0;
    offset += 2;

    // 4. OperationsSupported
    offset = mtp_pack_uint16_array(tx_buf, offset, supported_op, SUPPORTED_OP_COUNT);

    // 5. EventsSupported
    offset = mtp_pack_uint16_array(tx_buf, offset, supported_event, SUPPORTED_EVENT_COUNT);

    // 6. DevicePropertiesSupported
    extern const profile_property support_device_properties[];
    uint16_t dev_prop_codes[16];
    int dev_prop_count = 0;
    for (int i = 0; support_device_properties[i].prop_code != 0xFFFF; i++) {
        dev_prop_codes[dev_prop_count++] = support_device_properties[i].prop_code;
    }
    offset = mtp_pack_uint16_array(tx_buf, offset, dev_prop_codes, dev_prop_count);

    // 7. CaptureFormats
    offset = mtp_pack_uint16_array(tx_buf, offset, supported_capture_formats, SUPPORTED_CAPTURE_FORMATS_COUNT);

    // 8. PlaybackFormats
    offset = mtp_pack_uint16_array(tx_buf, offset, supported_playback_formats, SUPPORTED_PLAYBACK_FORMATS_COUNT);

    // 9. Manufacturer
    offset = mtp_pack_string(tx_buf, offset, MTP_MANUFACTURER_STRING);

    // 10. Model
    offset = mtp_pack_string(tx_buf, offset, MTP_MODEL_STRING);

    // 11. DeviceVersion
    offset = mtp_pack_string(tx_buf, offset, MTP_DEVICE_VERSION_STRING);

    // 12. SerialNumber
    offset = mtp_pack_string(tx_buf, offset, MTP_SERIAL_NUMBER_STRING);

    // === 构建响应头 ===
    struct mtp_header_withparam {
        struct mtp_header header;
        uint32_t session_id;
    } *resp = (struct mtp_header_withparam *)tx_buf;
    resp->header.conlen = offset;
    resp->header.contype = MTP_CONTAINER_TYPE_DATA;
    resp->header.code = MTP_OPERATION_GET_DEVICE_INFO;
    resp->header.trans_id = hdr->trans_id;
    resp->session_id = 0x12345678; // 示例会话ID
    return usbd_mtp_start_write(tx_buf, offset);

    // struct mtp_header *resp_hdr = (struct mtp_header*)tx_buf;
    // resp_hdr->conlen = offset;
    // resp_hdr->contype = MTP_CONTAINER_TYPE_DATA;
    // resp_hdr->code = MTP_OPERATION_GET_DEVICE_INFO;
    // resp_hdr->trans_id = hdr->trans_id;

    // return usbd_mtp_start_write(tx_buf, resp_hdr->conlen);
}

// 发送MTP响应
int mtp_send_response(uint16_t code, uint32_t trans_id)
{
   struct mtp_header *resp = (struct mtp_header *)g_usbd_mtp.tx_buffer;
    resp->conlen = sizeof(struct mtp_header);
    resp->contype = MTP_CONTAINER_TYPE_RESPONSE;
    resp->code = code;
    resp->trans_id = trans_id;

    MTP_LOGD("start send response: code=0x%04x, trans_id=0x%08x", code, trans_id);

    return usbd_mtp_start_write(g_usbd_mtp.tx_buffer, sizeof(struct mtp_header));
}

// 打开会话
static int mtp_open_session(struct mtp_header *hdr)
{
    if (hdr->conlen != sizeof(struct mtp_header) + 4) {
        return mtp_send_response(MTP_RESPONSE_INVALID_PARAMETER, hdr->trans_id);
    }

    g_usbd_mtp.session_id = hdr->param[0];
    g_usbd_mtp.session_open = true;
    
    return mtp_send_response(MTP_RESPONSE_OK, 0x12345678);
}

// 关闭会话
static int mtp_close_session(struct mtp_header *hdr)
{
    if (hdr->conlen != sizeof(struct mtp_header)) {
        return mtp_send_response(MTP_RESPONSE_INVALID_PARAMETER, hdr->trans_id);
    }

    g_usbd_mtp.session_open = false;
    g_usbd_mtp.session_id = 0;
    
    return mtp_send_response(MTP_RESPONSE_OK, hdr->trans_id);
}

// 获取存储ID列表
static int mtp_get_storage_ids(struct mtp_header *hdr)
{
    struct mtp_storage_id *storage_ids = (struct mtp_storage_id *)g_usbd_mtp.tx_buffer;
    
    // 填充存储ID
    storage_ids->StorageIDS_len = 1;
    storage_ids->StorageIDS[0] = MTP_STORAGE_ID;
    
    // 设置响应头
    struct mtp_header *resp = (struct mtp_header *)g_usbd_mtp.tx_buffer;
    resp->conlen = sizeof(struct mtp_header) + 8; // 4字节长度 + 4字节存储ID
    resp->contype = MTP_CONTAINER_TYPE_DATA;
    resp->code = MTP_OPERATION_GET_STORAGE_IDS;
    resp->trans_id = hdr->trans_id;
    
    return usbd_mtp_start_write(g_usbd_mtp.tx_buffer, resp->conlen);
}

// 获取存储信息
static int _mtp_get_storage_info(struct mtp_header *hdr)
{
    if (hdr->conlen != sizeof(struct mtp_header) + 4) {
        return mtp_send_response(MTP_RESPONSE_INVALID_PARAMETER, hdr->trans_id);
    }

    uint32_t storage_id = hdr->param[0];
    struct mtp_storage_info *info = (struct mtp_storage_info *)g_usbd_mtp.tx_buffer;
    
    // 获取存储信息
    if (mtp_get_storage_info(storage_id, info) != 0) {
        return mtp_send_response(MTP_RESPONSE_INVALID_STORAGE_ID, hdr->trans_id);
    }
    
    // 设置响应头
    struct mtp_header *resp = (struct mtp_header *)g_usbd_mtp.tx_buffer;
    resp->conlen = sizeof(struct mtp_header) + sizeof(struct mtp_storage_info);
    resp->contype = MTP_CONTAINER_TYPE_DATA;
    resp->code = MTP_OPERATION_GET_STORAGE_INFO;
    resp->trans_id = hdr->trans_id;
    
    return usbd_mtp_start_write(g_usbd_mtp.tx_buffer, resp->conlen);
}

// 获取对象句柄列表
static int mtp_get_object_handles(struct mtp_header *hdr)
{
    if (hdr->conlen != sizeof(struct mtp_header) + 8) {
        return mtp_send_response(MTP_RESPONSE_INVALID_PARAMETER, hdr->trans_id);
    }

    uint32_t storage_id = hdr->param[0];
    uint32_t format_code = hdr->param[1];
    uint32_t parent_handle = hdr->param[2];
    
    struct mtp_object_handles *handles = (struct mtp_object_handles *)g_usbd_mtp.tx_buffer;
    handles->ObjectHandle_len = 0;
    
    // 遍历对象池，查找符合条件的对象
    for (uint32_t i = 0; i < object_count; i++) {
        struct mtp_object *obj = &object_pool[i];
        
        if (obj->storage_id != storage_id) {
            continue;
        }
        
        if (format_code != 0x0000 && obj->format != format_code) {
            continue;
        }
        
        if (parent_handle != 0xFFFFFFFF && obj->parent_handle != parent_handle) {
            continue;
        }
        
        if (handles->ObjectHandle_len < 255) {
            handles->ObjectHandle[handles->ObjectHandle_len++] = obj->handle;
        }
    }
    
    // 设置响应头
    struct mtp_header *resp = (struct mtp_header *)g_usbd_mtp.tx_buffer;
    resp->conlen = sizeof(struct mtp_header) + 4 + (handles->ObjectHandle_len * 4);
    resp->contype = MTP_CONTAINER_TYPE_DATA;
    resp->code = MTP_OPERATION_GET_OBJECT_HANDLES;
    resp->trans_id = hdr->trans_id;
    
    return usbd_mtp_start_write(g_usbd_mtp.tx_buffer, resp->conlen);
}

// 获取对象信息
static int _mtp_get_object_info(struct mtp_header *hdr)
{
    if (hdr->conlen != sizeof(struct mtp_header) + 4) {
        return mtp_send_response(MTP_RESPONSE_INVALID_PARAMETER, hdr->trans_id);
    }

    uint32_t handle = hdr->param[0];
    struct mtp_object_info *info = (struct mtp_object_info *)g_usbd_mtp.tx_buffer;
    
    // 获取对象信息
    if (mtp_get_object_info(handle, info) != 0) {
        return mtp_send_response(MTP_RESPONSE_INVALID_OBJECT_HANDLE, hdr->trans_id);
    }
    
    // 设置响应头
    struct mtp_header *resp = (struct mtp_header *)g_usbd_mtp.tx_buffer;
    resp->conlen = sizeof(struct mtp_header) + sizeof(struct mtp_object_info);
    resp->contype = MTP_CONTAINER_TYPE_DATA;
    resp->code = MTP_OPERATION_GET_OBJECT_INFO;
    resp->trans_id = hdr->trans_id;
    
    return usbd_mtp_start_write(g_usbd_mtp.tx_buffer, resp->conlen);
}

// 获取对象数据
static int mtp_get_object(struct mtp_header *hdr)
{
    if (hdr->conlen != sizeof(struct mtp_header) + 4) {
        return mtp_send_response(MTP_RESPONSE_INVALID_PARAMETER, hdr->trans_id);
    }

    uint32_t handle = hdr->param[0];
    struct mtp_object *obj = mtp_object_find(handle);
    
    if (!obj) {
        return mtp_send_response(MTP_RESPONSE_INVALID_OBJECT_HANDLE, hdr->trans_id);
    }
    
    // 打开文件
    int fd = usbd_mtp_open(obj->file_full_name, MTP_FA_READ);
    if (fd < 0) {
        return mtp_send_response(MTP_RESPONSE_ACCESS_DENIED, hdr->trans_id);
    }
    
    // 发送响应头
    struct mtp_header *resp = (struct mtp_header *)g_usbd_mtp.tx_buffer;
    resp->conlen = sizeof(struct mtp_header),
    resp->contype = MTP_CONTAINER_TYPE_RESPONSE;
    resp->code = MTP_RESPONSE_OK;
    resp->trans_id = hdr->trans_id;
    
    if (usbd_mtp_start_write((uint8_t *)g_usbd_mtp.tx_buffer, sizeof(struct mtp_header)) != 0) {
        usbd_mtp_close(fd);
        return -1;
    }
    
    // 设置当前操作对象
    g_usbd_mtp.cur_object = obj;
    
    // 开始发送文件数据
    return mtp_send_object_data(fd);
}

// 发送对象数据
int mtp_send_object_data(int fd)
{
    // 读取文件数据
    int len = usbd_mtp_read(fd, g_usbd_mtp.tx_buffer, MTP_BUFFER_SIZE);
    if (len < 0) {
        usbd_mtp_close(fd);
        return mtp_send_response(MTP_RESPONSE_GENERAL_ERROR, g_usbd_mtp.transaction_id);
    }
    
    // 发送数据
    if (usbd_mtp_start_write(g_usbd_mtp.tx_buffer, len) != 0) {
        usbd_mtp_close(fd);
        return -1;
    }
    
    // 如果读取完毕，关闭文件
    if (len < MTP_BUFFER_SIZE) {
        usbd_mtp_close(fd);
    }
    
    return 0;
}

// 删除对象
static int mtp_delete_object(struct mtp_header *hdr)
{
    if (hdr->conlen != sizeof(struct mtp_header) + 4) {
        return mtp_send_response(MTP_RESPONSE_INVALID_PARAMETER, hdr->trans_id);
    }

    uint32_t handle = hdr->param[0];
    struct mtp_object *obj = mtp_object_find(handle);
    
    if (!obj) {
        return mtp_send_response(MTP_RESPONSE_INVALID_OBJECT_HANDLE, hdr->trans_id);
    }
    
    // 删除文件或目录
    int ret;
    if (obj->is_dir) {
        ret = usbd_mtp_rmdir(obj->file_full_name);
    } else {
        ret = usbd_mtp_unlink(obj->file_full_name);
    }
    
    if (ret != 0) {
        return mtp_send_response(MTP_RESPONSE_ACCESS_DENIED, hdr->trans_id);
    }
    
    // 从对象池中移除
    memset(obj, 0, sizeof(struct mtp_object));
    
    return mtp_send_response(MTP_RESPONSE_OK, hdr->trans_id);
}

// 发送对象信息
static int mtp_send_object_info(struct mtp_header *hdr)
{
    if (hdr->conlen < sizeof(struct mtp_header) + sizeof(struct mtp_object_info)) {
        return mtp_send_response(MTP_RESPONSE_INVALID_PARAMETER, hdr->trans_id);
    }

    // 解析对象信息
    struct mtp_object_info *info = (struct mtp_object_info *)(hdr + 1);
    
    // 创建新对象
    struct mtp_object *obj = mtp_object_add(info->ParentObject, 
                                           (char *)info->Filename, 
                                           info->ObjectFormat,
                                           info->AssociationType == MTP_ASSOCIATION_TYPE_GENERIC_FOLDER);
    
    if (!obj) {
        return mtp_send_response(MTP_RESPONSE_STORAGE_FULL, hdr->trans_id);
    }
    
    // 设置当前操作对象
    g_usbd_mtp.cur_object = obj;
    
    // 发送响应
    struct mtp_header_withparam {
        struct mtp_header header;
        uint32_t handle;
    } *resp = (struct mtp_header_withparam *)g_usbd_mtp.tx_buffer;

    resp->header.conlen = sizeof(struct mtp_header) + 4,
    resp->header.contype = MTP_CONTAINER_TYPE_RESPONSE;
    resp->header.code = MTP_RESPONSE_OK;
    resp->header.trans_id = hdr->trans_id,
    resp->handle = obj->handle;
    
    return usbd_mtp_start_write((uint8_t *)g_usbd_mtp.tx_buffer, resp->header.conlen);
}

// 发送对象数据
static int mtp_send_object(struct mtp_header *hdr)
{
    if (!g_usbd_mtp.cur_object) {
        return mtp_send_response(MTP_RESPONSE_INVALID_OBJECT_HANDLE, hdr->trans_id);
    }

    // 打开文件准备写入
    int fd = usbd_mtp_open(g_usbd_mtp.cur_object->file_full_name, MTP_FA_WRITE | MTP_FA_CREATE_ALWAYS);
    if (fd < 0) {
        return mtp_send_response(MTP_RESPONSE_ACCESS_DENIED, hdr->trans_id);
    }
    
    // 写入数据
    int len = usbd_mtp_write(fd, (hdr + 1), hdr->conlen - sizeof(struct mtp_header));
    usbd_mtp_close(fd);
    
    if (len < 0) {
        return mtp_send_response(MTP_RESPONSE_STORAGE_FULL, hdr->trans_id);
    }
    
    // 更新对象大小
    g_usbd_mtp.cur_object->file_size = len;
    
    // 清除当前操作对象
    g_usbd_mtp.cur_object = NULL;
    
    return mtp_send_response(MTP_RESPONSE_OK, hdr->trans_id);
}

// 获取设备属性描述
static int mtp_get_device_prop_desc(struct mtp_header *hdr)
{
    if (hdr->conlen != sizeof(struct mtp_header) + 4) {
        return mtp_send_response(MTP_RESPONSE_INVALID_PARAMETER, hdr->trans_id);
    }

    uint16_t prop_code = hdr->param[0];
    struct mtp_device_prop_desc *desc = (struct mtp_device_prop_desc *)g_usbd_mtp.tx_buffer;
    
    // 查找支持的设备属性
    const profile_property *prop = NULL;
    for (int i = 0; support_device_properties[i].prop_code != 0xFFFF; i++) {
        if (support_device_properties[i].prop_code == prop_code) {
            prop = &support_device_properties[i];
            break;
        }
    }
    
    if (!prop) {
        return mtp_send_response(MTP_RESPONSE_DEVICE_PROP_NOT_SUPPORTED, hdr->trans_id);
    }
    
    // 填充属性描述
    memset(desc, 0, sizeof(*desc));
    desc->DevicePropertyCode = prop->prop_code;
    desc->DataType = prop->data_type;
    desc->GetSet = prop->getset;
    
    // 设置默认值和当前值
    switch (prop->data_type) {
        case MTP_TYPE_UINT16:
            desc->DefaultValue[0] = (uint16_t)prop->default_value;
            desc->CurrentValue[0] = (uint16_t)prop->default_value;
            break;
        case MTP_TYPE_UINT32:
            *(uint32_t *)desc->DefaultValue = (uint32_t)prop->default_value;
            *(uint32_t *)desc->CurrentValue = (uint32_t)prop->default_value;
            break;
        case MTP_TYPE_STR:
            // 字符串类型需要特殊处理
            break;
        default:
            break;
    }
    
    // 设置响应头
    struct mtp_header *resp = (struct mtp_header *)g_usbd_mtp.tx_buffer;
    resp->conlen = sizeof(struct mtp_header) + sizeof(struct mtp_device_prop_desc);
    resp->contype = MTP_CONTAINER_TYPE_DATA;
    resp->code = MTP_OPERATION_GET_DEVICE_PROP_DESC;
    resp->trans_id = hdr->trans_id;
    
    return usbd_mtp_start_write(g_usbd_mtp.tx_buffer, resp->conlen);
}

// 获取对象支持的属性列表
static int mtp_get_object_props_supported(struct mtp_header *hdr)
{
    if (hdr->conlen != sizeof(struct mtp_header) + 4) {
        return mtp_send_response(MTP_RESPONSE_INVALID_PARAMETER, hdr->trans_id);
    }

    uint16_t format_code = hdr->param[0];
    struct mtp_object_props_support *props = (struct mtp_object_props_support *)g_usbd_mtp.tx_buffer;
    
    // 查找支持的格式属性
    props->ObjectPropCode_len = 0;
    for (int i = 0; support_format_properties[i].format_code != 0xFFFF; i++) {
        if (support_format_properties[i].format_code == format_code) {
            uint16_t *prop_list = support_format_properties[i].properties;
            while (*prop_list != 0xFFFF) {
                props->ObjectPropCode[props->ObjectPropCode_len++] = *prop_list++;
            }
            break;
        }
    }
    
    // 设置响应头
    struct mtp_header *resp = (struct mtp_header *)g_usbd_mtp.tx_buffer;
    resp->conlen = sizeof(struct mtp_header) + 4 + (props->ObjectPropCode_len * 2);
    resp->contype = MTP_CONTAINER_TYPE_DATA;
    resp->code = MTP_OPERATION_GET_OBJECT_PROPS_SUPPORTED;
    resp->trans_id = hdr->trans_id;
    
    return usbd_mtp_start_write(g_usbd_mtp.tx_buffer, resp->conlen);
}

// 处理MTP命令
int mtp_command_handler(uint8_t *data, uint32_t len)
{
    struct mtp_header *hdr = (struct mtp_header *)data;
    
    // 检查会话状态(除OpenSession外都需要有效会话)
    if (hdr->code != MTP_OPERATION_OPEN_SESSION && !g_usbd_mtp.session_open) {
        return mtp_send_response(MTP_RESPONSE_SESSION_NOT_OPEN, hdr->trans_id);
    }

    MTP_LOGD("contype = 0x%04x, code = 0x%04x, trans_id = 0x%08x",
                hdr->contype, hdr->code, hdr->trans_id);

    // 根据操作码分发处理
    switch (hdr->code) {
        case MTP_OPERATION_OPEN_SESSION:
            return mtp_open_session(hdr);
        case MTP_OPERATION_CLOSE_SESSION:
            return mtp_close_session(hdr);
        case MTP_OPERATION_GET_DEVICE_INFO:
            return mtp_get_device_info(hdr);
        case MTP_OPERATION_GET_STORAGE_IDS:
            return mtp_get_storage_ids(hdr);
        case MTP_OPERATION_GET_STORAGE_INFO:
            return _mtp_get_storage_info(hdr);
        case MTP_OPERATION_GET_OBJECT_HANDLES:
            return mtp_get_object_handles(hdr);
        case MTP_OPERATION_GET_OBJECT_INFO:
            return _mtp_get_object_info(hdr);
        case MTP_OPERATION_GET_OBJECT:
            return mtp_get_object(hdr);
        case MTP_OPERATION_DELETE_OBJECT:
            return mtp_delete_object(hdr);
        case MTP_OPERATION_SEND_OBJECT_INFO:
            return mtp_send_object_info(hdr);
        case MTP_OPERATION_SEND_OBJECT:
            return mtp_send_object(hdr);
        case MTP_OPERATION_GET_DEVICE_PROP_DESC:
            return mtp_get_device_prop_desc(hdr);
        case MTP_OPERATION_GET_OBJECT_PROPS_SUPPORTED:
            return mtp_get_object_props_supported(hdr);
        default:
            return mtp_send_response(MTP_RESPONSE_OPERATION_NOT_SUPPORTED, hdr->trans_id);
    }
}