/*
 * Copyright (c) 2025, sakumisu
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#ifndef MTP_STORAGE_H
#define MTP_STORAGE_H

#include "usb_mtp.h"

void mtp_storage_init(void);
int mtp_get_storage_info(uint32_t storage_id, struct mtp_storage_info *info);
struct mtp_object *mtp_object_find(uint32_t handle);
struct mtp_object *mtp_object_add(uint32_t parent_handle, const char *name, uint16_t format, bool is_dir);
int mtp_get_object_info(uint32_t handle, struct mtp_object_info *info);

#endif /* MTP_STORAGE_H */