/*
 * Copyright (c) 2025, [Your Name]
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#include "mtp_filesystem.h"
#include "usbd_mtp.h"

// ==== 简单字符串和内存操作 ====
static void mtp_memset(void *dst, int v, size_t n) {
    uint8_t *p = (uint8_t*)dst;
    while (n--) *p++ = (uint8_t)v;
}
static void mtp_memcpy(void *dst, const void *src, size_t n) {
    uint8_t *d = (uint8_t*)dst;
    const uint8_t *s = (const uint8_t*)src;
    while (n--) *d++ = *s++;
}
static int mtp_strcmp(const char *a, const char *b) {
    while (*a && *b && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}
static int mtp_strncmp(const char *a, const char *b, size_t n) {
    while (n && *a && *b && *a == *b) { a++; b++; n--; }
    if (n == 0) return 0;
    return (unsigned char)*a - (unsigned char)*b;
}
static size_t mtp_strlen(const char *s) {
    size_t l = 0;
    while (*s++) l++;
    return l;
}
static void mtp_strncpy(char *dst, const char *src, size_t n) {
    while (n && *src) { *dst++ = *src++; n--; }
    while (n--) *dst++ = 0;
}

// ==== 简单内存分配（静态池）====
#define MTP_FILE_DATA_POOL_SIZE (1024*16)
// static uint8_t mtp_file_data_pool[MTP_FILE_DATA_POOL_SIZE];
static size_t mtp_file_data_pool_used = 0;
static void *mtp_malloc(size_t sz) {
    // if (mtp_file_data_pool_used + sz > MTP_FILE_DATA_POOL_SIZE) return 0;
    // void *p = &mtp_file_data_pool[mtp_file_data_pool_used];
    // mtp_file_data_pool_used += sz;
    // return p;
    return rt_malloc(sz); // 使用操作系统的内存分配
}
static void mtp_free(void *p) 
{ 
    rt_free(p);
    // (void)p; 
    /* 不做释放，模拟环境 */ 
}

// ==== 全局变量 ====
static mtp_file_entry_t mtp_root_files[100];
static mtp_dir_entry_t mtp_root_dir = { "/", {0}, 0 };
static mtp_dir_entry_t *mtp_current_dir = &mtp_root_dir;
static mtp_file_entry_t *mtp_open_file = 0;
static size_t mtp_open_file_pos = 0;
static uint32_t mtp_current_time = 0;

const char mtp_driver_num_buf[4] = { '0', ':', '/', '\0' };

// ==== 平台接口的空实现 ====
static uint32_t mtp_get_current_time(void) {
    return mtp_current_time++;
}

// ==== 错误字符串函数 ====
const char *mtp_show_error_string(int result) {
    switch (result) {
        case 0: return "succeeded";
        case -1: return "general error";
        case -2: return "file not found";
        case -3: return "path not found";
        case -4: return "invalid name";
        case -5: return "access denied";
        case -6: return "file exists";
        case -7: return "invalid object";
        case -8: return "write protected";
        case -9: return "not enough space";
        case -10: return "too many open files";
        default: return "unknown error";
    }
}

const char *usbd_mtp_fs_root_path(void) { return mtp_driver_num_buf; }
const char *usbd_mtp_fs_description(void) { return "Mock MTP File System"; }

// ==== 内部辅助函数 ====
static mtp_file_entry_t *mtp_find_file(const char *path) {
    const char *filename = path;
    if (mtp_strncmp(path, "0:/", 3) == 0) filename = path + 3;
    for (int i = 0; i < mtp_root_dir.file_count; i++) {
        if (mtp_strcmp(mtp_root_dir.files[i]->name, filename) == 0) {
            return mtp_root_dir.files[i];
        }
    }
    return 0;
}
static mtp_dir_entry_t *mtp_find_dir(const char *path) {
    if (mtp_strcmp(path, "/") == 0 || mtp_strcmp(path, "0:/") == 0) return &mtp_root_dir;
    return 0;
}

// ==== MTP接口实现 ====
int usbd_mtp_mkdir(const char *path) {
    if (mtp_find_dir(path) != 0) return -6;
    if (mtp_root_dir.file_count >= 100) return -9;
    mtp_file_entry_t *new_dir = &mtp_root_files[mtp_root_dir.file_count];
    mtp_memset(new_dir, 0, sizeof(mtp_file_entry_t));
    const char *dirname = path;
    if (mtp_strncmp(path, "0:/", 3) == 0) dirname = path + 3;
    mtp_strncpy(new_dir->name, dirname, 255);
    new_dir->type = MTP_FILE_TYPE_DIRECTORY;
    new_dir->attributes = MTP_AM_DIR;
    new_dir->create_time = mtp_get_current_time();
    new_dir->modify_time = new_dir->create_time;
    mtp_root_dir.files[mtp_root_dir.file_count] = new_dir;
    mtp_root_dir.file_count++;
    return 0;
}

int usbd_mtp_rmdir(const char *path) {
    mtp_file_entry_t *dir = mtp_find_file(path);
    if (dir == 0) return -2;
    if (!(dir->attributes & MTP_AM_DIR)) return -7;
    mtp_memset(dir, 0, sizeof(mtp_file_entry_t));
    return 0;
}

void *usbd_mtp_opendir(const char *name) {
    mtp_dir_entry_t *dir = mtp_find_dir(name);
    return (void *)dir;
}

int usbd_mtp_closedir(void *dir) { (void)dir; return 0; }

struct mtp_dirent *usbd_mtp_readdir(void *dir) {
    static struct mtp_dirent dirent;
    mtp_dir_entry_t *d = (mtp_dir_entry_t *)dir;
    static int index = 0;
    if (index >= d->file_count) { index = 0; return 0; }
    mtp_memset(&dirent, 0, sizeof(struct mtp_dirent));
    mtp_strncpy(dirent.d_name, d->files[index]->name, 255);
    dirent.d_namlen = mtp_strlen(dirent.d_name);
    index++;
    return &dirent;
}

int usbd_mtp_stat(const char *path, struct mtp_stat *buf) {
    mtp_file_entry_t *file = mtp_find_file(path);
    if (file == 0) {
        mtp_dir_entry_t *dir = mtp_find_dir(path);
        if (dir == 0) return -2;
        mtp_memset(buf, 0, sizeof(struct mtp_stat));
        buf->st_mode = 0040777;
        if (file && (file->attributes & MTP_AM_RDO)) buf->st_mode &= ~0222;
        return 0;
    }
    mtp_memset(buf, 0, sizeof(struct mtp_stat));
    buf->st_mode = 0100777;
    if (file->attributes & MTP_AM_RDO) buf->st_mode &= ~0222;
    buf->st_size = file->size;
    buf->st_blksize = 512;
    buf->st_blocks = (file->size + 511) / 512;
    return 0;
}

int usbd_mtp_statfs(const char *path, struct mtp_statfs *buf) {
    (void)path;
    buf->f_bsize = 512;
    buf->f_blocks = 1000;
    buf->f_bfree = 500;
    return 0;
}

int usbd_mtp_open(const char *path, uint8_t mode) {
    mtp_file_entry_t *file = mtp_find_file(path);
    if (mode == MTP_FA_READ) {
        if (file == 0) return -2;
    } else if (mode & MTP_FA_WRITE) {
        if (file == 0) {
            if (mtp_root_dir.file_count >= 100) return -9;
            file = &mtp_root_files[mtp_root_dir.file_count];
            mtp_memset(file, 0, sizeof(mtp_file_entry_t));
            const char *filename = path;
            if (mtp_strncmp(path, "0:/", 3) == 0) filename = path + 3;
            mtp_strncpy(file->name, filename, 255);
            file->type = MTP_FILE_TYPE_REGULAR;
            file->create_time = mtp_get_current_time();
            file->modify_time = file->create_time;
            mtp_root_dir.files[mtp_root_dir.file_count] = file;
            mtp_root_dir.file_count++;
        }
    } else {
        return -1;
    }
    mtp_open_file = file;
    mtp_open_file_pos = 0;
    return 0;
}

int usbd_mtp_close(int fd) {
    (void)fd;
    mtp_open_file = 0;
    mtp_open_file_pos = 0;
    return 0;
}

int usbd_mtp_read(int fd, void *buf, size_t len) {
    (void)fd;
    if (mtp_open_file == 0) return -1;
    size_t remaining = mtp_open_file->size - mtp_open_file_pos;
    if (len > remaining) len = remaining;
    if (len > 0) {
        mtp_memcpy(buf, mtp_open_file->data + mtp_open_file_pos, len);
        mtp_open_file_pos += len;
    }
    return (int)len;
}

int usbd_mtp_write(int fd, const void *buf, size_t len) {
    (void)fd;
    if (mtp_open_file == 0) return -1;
    if (mtp_open_file_pos + len > mtp_open_file->size) {
        size_t new_size = mtp_open_file_pos + len;
        uint8_t *new_data = (uint8_t*)mtp_malloc(new_size);
        if (new_data == 0) return -9;
        if (mtp_open_file->data && mtp_open_file->size > 0)
            mtp_memcpy(new_data, mtp_open_file->data, mtp_open_file->size);
        mtp_open_file->data = new_data;
        mtp_open_file->size = new_size;
    }
    mtp_memcpy(mtp_open_file->data + mtp_open_file_pos, buf, len);
    mtp_open_file_pos += len;
    mtp_open_file->modify_time = mtp_get_current_time();
    return (int)len;
}

int usbd_mtp_unlink(const char *path) {
    mtp_file_entry_t *file = mtp_find_file(path);
    if (file == 0) return -2;
    if (file->attributes & MTP_AM_DIR) return -7;
    if (file->data != 0) mtp_free(file->data);
    mtp_memset(file, 0, sizeof(mtp_file_entry_t));
    return 0;
}

void usbd_mtp_mount() {
    mtp_memset(&mtp_root_dir, 0, sizeof(mtp_root_dir));
    mtp_strncpy(mtp_root_dir.name, "/", 255);
    mtp_root_dir.file_count = 0;
    usbd_mtp_open("0:/readme.txt", MTP_FA_WRITE | MTP_FA_CREATE_ALWAYS);
    const char *test_content = "Hello, this is mock file system demo\n";
    usbd_mtp_write(0, test_content, mtp_strlen(test_content));
    usbd_mtp_close(0);
    // 模拟环境不
}