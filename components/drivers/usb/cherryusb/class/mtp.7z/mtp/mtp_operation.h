/*
 * Copyright (c) 2025, sakumisu
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#ifndef MTP_OPERATION_H
#define MTP_OPERATION_H

#include <stdint.h>

int mtp_command_handler(uint8_t *data, uint32_t len);
int mtp_send_response(uint16_t code, uint32_t trans_id);
int mtp_send_object_data(int fd);

#endif /* MTP_OPERATION_H */