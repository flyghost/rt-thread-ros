/*
 * Copyright (c) 2025, sakumisu
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * MTP存储管理实现
 */

#include "mtp_storage.h"
#include "usbd_mtp.h"
#include <string.h>
#include <stdio.h>


// 存储ID定义
#define MTP_STORAGE_ID 0x00010001

// 对象句柄管理
struct mtp_object object_pool[CONFIG_USBDEV_MTP_MAX_OBJECTS];
uint32_t object_count = 0;

// 存储初始化
void mtp_storage_init(void)
{
    // 清空对象池
    memset(object_pool, 0, sizeof(object_pool));
    object_count = 0;
    
    // 添加根目录对象
    struct mtp_object *root = &object_pool[object_count++];
    root->storage_id = MTP_STORAGE_ID;
    root->handle = 0x00000001; // 根对象句柄
    root->parent_handle = 0x00000000; // 无父对象
    root->format = MTP_FORMAT_ASSOCIATION;
    root->is_dir = true;
    strncpy(root->file_full_name, usbd_mtp_fs_root_path(), CONFIG_USBDEV_MTP_MAX_PATHNAME);
}

// 获取存储信息
int mtp_get_storage_info(uint32_t storage_id, struct mtp_storage_info *info)
{
    if (storage_id != MTP_STORAGE_ID) {
        return -1;
    }

    // 获取文件系统信息
    struct mtp_statfs stat;
    if (usbd_mtp_statfs(usbd_mtp_fs_root_path(), &stat) != 0) {
        return -1;
    }

    // 填充存储信息
    memset(info, 0, sizeof(*info));
    info->StorageType = MTP_STORAGE_FIXED_RAM;
    info->FilesystemType = MTP_STORAGE_FILESYSTEM_HIERARCHICAL;
    info->AccessCapability = MTP_STORAGE_READ_WRITE;
    info->MaxCapability = stat.f_bsize * stat.f_blocks;
    info->FreeSpaceInBytes = stat.f_bsize * stat.f_bfree;
    info->FreeSpaceInObjects = 0; // 不支持对象限制
    
    // 设置存储描述
    const char *desc = usbd_mtp_fs_description();
    info->StorageDescription_len = strlen(desc);
    memcpy(info->StorageDescription, desc, info->StorageDescription_len);
    
    return 0;
}

// 查找对象
struct mtp_object *mtp_object_find(uint32_t handle)
{
    for (uint32_t i = 0; i < object_count; i++) {
        if (object_pool[i].handle == handle) {
            return &object_pool[i];
        }
    }
    return NULL;
}

// 添加新对象
struct mtp_object *mtp_object_add(uint32_t parent_handle, const char *name, uint16_t format, bool is_dir)
{
    if (object_count >= CONFIG_USBDEV_MTP_MAX_OBJECTS) {
        return NULL;
    }

    struct mtp_object *parent = mtp_object_find(parent_handle);
    if (!parent) {
        return NULL;
    }

    struct mtp_object *obj = &object_pool[object_count++];
    memset(obj, 0, sizeof(*obj));
    
    // 设置对象属性
    obj->storage_id = MTP_STORAGE_ID;
    obj->handle = 0x80000000 + object_count; // 生成唯一句柄
    obj->parent_handle = parent_handle;
    obj->format = format;
    obj->is_dir = is_dir;
    
    // 构建完整路径
    snprintf(obj->file_full_name, CONFIG_USBDEV_MTP_MAX_PATHNAME, 
             "%s/%s", parent->file_full_name, name);
    
    return obj;
}

// 获取对象信息
int mtp_get_object_info(uint32_t handle, struct mtp_object_info *info)
{
    struct mtp_object *obj = mtp_object_find(handle);
    if (!obj) {
        return -1;
    }

    // 获取文件状态
    struct mtp_stat st;
    if (usbd_mtp_stat(obj->file_full_name, &st) != 0) {
        return -1;
    }

    // 填充对象信息
    memset(info, 0, sizeof(*info));
    info->StorageId = obj->storage_id;
    info->ObjectFormat = obj->format;
    info->ObjectCompressedSize = st.st_size;
    info->ParentObject = obj->parent_handle;
    info->AssociationType = obj->is_dir ? MTP_ASSOCIATION_TYPE_GENERIC_FOLDER : 0;
    
    // 设置文件名
    const char *name = strrchr(obj->file_full_name, '/');
    if (name) name++; else name = obj->file_full_name;
    info->Filename_len = strlen(name);
    memcpy(info->Filename, name, info->Filename_len);
    
    // TODO: 设置日期时间等其他属性
    
    return 0;
}