#ifndef MTP_FILESYSTEM_H
#define MTP_FILESYSTEM_H

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>

// ==== 基础类型定义 ====
// size_t 直接用标准库定义

// ==== 文件属性和类型定义 ====
#define MTP_AM_RDO  0x01
#define MTP_AM_HID  0x02
#define MTP_AM_SYS  0x04
#define MTP_AM_DIR  0x10
#define MTP_AM_ARC  0x20

#define MTP_FA_READ          0x01
#define MTP_FA_WRITE         0x02
#define MTP_FA_OPEN_EXISTING 0x00
#define MTP_FA_CREATE_NEW    0x04
#define MTP_FA_CREATE_ALWAYS 0x08
#define MTP_FA_OPEN_ALWAYS   0x10

typedef enum {
    MTP_FILE_TYPE_REGULAR,
    MTP_FILE_TYPE_DIRECTORY
} mtp_file_type_t;

struct mtp_stat {
    uint32_t st_mode;
    uint64_t st_size;
    uint32_t st_blksize;
    uint64_t st_blocks;
};

// struct mtp_dirent {
//     char d_name[256];
//     uint32_t d_namlen;
// };

// struct mtp_statfs {
//     uint64_t f_blocks;
//     uint64_t f_bfree;
//     uint32_t f_bsize;
// };

typedef struct mtp_file_entry {
    char name[256];
    mtp_file_type_t type;
    size_t size;
    uint8_t *data;
    uint32_t create_time;
    uint32_t modify_time;
    uint8_t attributes;
} mtp_file_entry_t;

typedef struct mtp_dir_entry {
    char name[256];
    mtp_file_entry_t *files[100];
    int file_count;
} mtp_dir_entry_t;


#endif